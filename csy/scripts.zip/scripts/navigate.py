import rospy
from geometry_msgs.msg import PoseStamped
from actionlib_msgs.msg import GoalStatusArray
import rospy
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion


class Navigator:
    def __init__(self):
        
        self.current_pose = None
        self.goal_position = None
        self.goal_publisher = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
        
        rospy.Subscriber('/odom', Odometry, self.odom_callback)
       

    def navigate_to_point(self,entrance_position):
        # 初始化ROS节点
    

        # 创建目标点消息
        goal = PoseStamped()
        goal.header.frame_id = 'map'
        goal.pose.position.x = entrance_position[0]
        goal.pose.position.y = entrance_position[1]
        goal.pose.position.z = entrance_position[2]
        goal.pose.orientation.x = entrance_position[3]
        goal.pose.orientation.y = entrance_position[4]
        goal.pose.orientation.z = entrance_position[5]
        goal.pose.orientation.w = entrance_position[6]  # 默认朝向

        # 发布目标点消息
        
        self.goal_publisher.publish(goal)

        rospy.loginfo('Published navigation goal: (p_x={}, p_y={}, p_z={}, o_x={}, o_y={}, o_z={}, o_w={})'.format(
    goal.pose.position.x, goal.pose.position.x, goal.pose.position.z, goal.pose.orientation.x,
    goal.pose.orientation.y, goal.pose.orientation.z, goal.pose.orientation.w))


    

    def odom_callback(self, msg):
        self.current_pose = msg.pose.pose

        if self.goal_position is not None:
            current_position = self.current_pose.position
            distance_to_goal = ((current_position.x - self.goal_position[0]) ** 2 +
                                (current_position.y - self.goal_position[1]) ** 2) ** 0.5

            if distance_to_goal < 0.05:  # 调整此阈值以控制达到目标点的距离
                
                rospy.loginfo('Reached navigation goal!')
                return True




