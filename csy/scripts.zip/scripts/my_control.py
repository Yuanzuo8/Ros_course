#!/usr/bin/python3

import rospy
import base64
import urllib
import os
import numpy as np

from sensor_msgs.msg import Image

import cv2

from cv_bridge import CvBridge
import requests
import json
import dlib
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib import animation
import cv2
import paddlehub as hub
import PIL.Image as Image_pil
from PIL import ImageSequence
from IPython.display import display, HTML
import numpy as np
import imageio
import os
import time
import os
import rospy
import smach
import smach_ros
import wave
import pyaudio
import threading
from concurrent.futures import ThreadPoolExecutor
from face_recognize_module import FaceRecognizer
from segment_module import PeopleSegmentation
from pydub import AudioSegment
from pydub.playback import play
import rospy
from api_module import GetPersonalInformation
from navigate import Navigator
from geometry_msgs.msg import PoseStamped
from face_detected import FaceDetector
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
entrance = True
entrance_position=[1,0.306,0,0,0,1,-0.02]
next = False
is_find = False
img_color = None
binary_mask=None
contours=None
depth_image = None
distance_image = None
closest_name=None
text_location=None
scaling_factor = 0.001  # 缩放因子，将深度值从毫米转换为米
face_recognizer=FaceRecognizer()
segmenter = PeopleSegmentation()
navigator = Navigator()
api_detect = GetPersonalInformation()
face_detect = FaceDetector()
draw_times=0
faces = None
face_list=None
def callback_color(imgmsg):
    bridge = CvBridge()
    global img_color
   
    img_color = bridge.imgmsg_to_cv2(imgmsg, "bgr8")
    
    global is_find
    
    global binary_mask,contours
    [is_find,binary_mask,contours]=segmenter.segment_people(img_color)
   
    draw()
def callback_depth(img_depth):
    bridge = CvBridge()
    global depth_image
    global distance_image 
    global scaling_factor
    depth_image = bridge.imgmsg_to_cv2(img_depth, desired_encoding='passthrough')
    
    distance_image = depth_image * scaling_factor

def draw():
    
    global img_color
    global contours
    global text_location
    global closest_name
    # print("contours2:",contours)
    if img_color is not None:
      
        if contours is not None:
            #同时时刻进行人脸识别不过每个人都打上不知道的标签
            cv2.drawContours(img_color, contours, -1, (0, 255, 0), 2)
            if closest_name is not None:
                # 计算横坐标（x）的均值和纵坐标（y）的最小值
             
                contour_array = contours[0]

                # 创建空列表来存储横坐标和纵坐标
                x_coordinates = []
                y_coordinates = []

                # 遍历contour_array数组，提取横坐标和纵坐标，并分别添加到列表中
                for contour in contour_array:
                    x_coordinates.append(contour[0][0])
                    y_coordinates.append(contour[0][1])

                # 计算横坐标的均值和纵坐标的最小值
                x_mean = np.mean(x_coordinates)
                y_min = np.min(y_coordinates)

                

                # 设置text_location为均值x_mean和最小值y_min的坐标
                text_location = (int(x_mean), int(y_min))
                cv2.putText(img_color, closest_name, text_location, cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            global face_list
            if face_list is not None:
                for face in face_list:
                    left = int(face["location"]["left"])
                    top = int(face["location"]["top"])
                    width = int(face["location"]["width"])
                    height = int(face["location"]["height"])

                    # 绘制检测框
                    cv2.rectangle(img_color, (left, top), (left + width, top + height), (0, 255, 0), 2)

                    # 构造标签字符串
                    label = f"Age: {face['age']}, Gender: {face['gender']['type']}"

                    # 绘制标签文本
                    cv2.putText(img_color, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.imshow('Detected Contours', img_color)
        cv2.waitKey(1)
def play_wav(file_path):
    audio = AudioSegment.from_wav(file_path)

    # 播放音频
    play(audio)
class Welcome(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['transition_to_register'])

    def execute(self, userdata):
        global next
        next = False
        global is_find
        global entrance
        rospy.loginfo('Go to Entrance')
        if(entrance):
            navigator.navigate_to_point(entrance_position)
            while(not navigator.odom_callback):
                
                rospy.sleep(0.2)
        rospy.loginfo('Welcome')
        # print("img_color:",img_color)
        
        while(img_color is None or is_find is False):
            rospy.sleep(0.1)
        
        if(img_color is not None and next is False and is_find is not False):
            
            
            print("is_find:",is_find)
            if is_find:
                play_wav("欢迎光临！请问您叫什么名字？.wav")
                next = True
        if next is True:
            return 'transition_to_register'
        return 'transition_to_register'      
                
           
        
class register(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['transition_to_Welcome'])
        
    def execute(self, userdata):
        global next
        global closest_name
        global is_find
        next = False
        rospy.loginfo('register')
        while(img_color is None or is_find is False):
            continue
        if(img_color is not None and next is False):
            # while(closest_name is None):
            #     global text_location
            #     [closest_name,text_location]=face_recognizer.feature_get(img_color)
            #     print(closest_name)
            global face_list
            detect=api_detect.get_detect(img_color)
            face_list = detect['result']['face_list']
            #选择年龄最小的那一个
            #记录其名字
            #替换其标签为其名字
            #给他编码
            #这时候删除其他所有人的检测标签,图像中仅仅对其一个人进行检测并显示其姓名喜好
            #然后借助于人脸检测
            next = True
        while True:
            rospy.sleep(0.1)
            
        
        if next is True:
            return 'transition_to_Welcome'


    # print(img.shape)

    
    
# 订阅话题的回调函数


   

    


         
def main():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber("/camera/rgb/image_color", Image, callback_color)
    rospy.sleep(0.5)
    sm = smach.StateMachine(outcomes=['ros_shutdown'])
    with sm:
        smach.StateMachine.add('Welcome', Welcome(), transitions={'transition_to_register': 'register'})
        smach.StateMachine.add('register', register(), transitions={'transition_to_Welcome': 'Welcome'})

    sis = smach_ros.IntrospectionServer('smach_server', sm, '/SM_ROOT')
    sis.start()

    outcome = sm.execute()

    sis.stop() 
    if outcome == 'ros_shutdown':
        rospy.signal_shutdown('ROS state machine example complete')
    rospy.spin()
    
    
    
    
    
    
    
    

if __name__ == '__main__':
    main()

